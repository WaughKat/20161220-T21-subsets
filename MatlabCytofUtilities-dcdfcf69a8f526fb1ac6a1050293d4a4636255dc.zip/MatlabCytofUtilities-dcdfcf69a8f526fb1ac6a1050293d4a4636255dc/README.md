MatlabCytofUtilities
====================

various scripts and functions that can be useful when working with mass (or flow) cytometry data in Matlab
